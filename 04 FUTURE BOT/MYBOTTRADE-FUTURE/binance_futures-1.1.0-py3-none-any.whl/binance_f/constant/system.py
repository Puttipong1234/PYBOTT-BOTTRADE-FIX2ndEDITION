
class WebSocketDefine:
#    Uri = "wss://stream.binancefuture.com/ws"
    Uri = "wss://fstream.binance.com/ws"

class RestApiDefine:
#     Url = "https://testnet.binancefuture.com"
    Url = "https://fapi.binance.com"





